 //variables
  let mx = 0
  let my = 0
  let pmx = 0
  let pmy = 0
  let f = 0

//setup
function setup() {
  createCanvas(600, 600);

  let f = 25
  frameRate(f);
}

function draw() {
  background(230);
   colorMode(RGB, 255, 255, 255,1);

   let f = sqrt(2000);
   frameRate(f);

     let mx = mouseX
  let my = mouseY
  let pmx = pmouseX
  let pmy = pmouseY

//pmousex 

let weight = dist(mx,my,pmx,pmy)

 noFill();
 strokeWeight(weight);
 stroke(204,0,102);
 ellipse(pmx,pmy,110,110);


// main shape
 
  strokeWeight(5);
   stroke(255,102,102);
   ellipse(mx,my, 100,100);

   stroke(255,178,102);
   ellipse(mx,my,80,80);

   stroke(255,255,102);
   ellipse(mx,my,60,60);

   stroke(102,255,102);
   ellipse(mx,my,40,40);

  stroke(102,255,255);
  ellipse(mx,my,20,20);

  stroke(178,102,255);
  point(mx,my) 

//requirements: 
//gray background [X]
//rgb colormode [X]
//3 variables [X]
//frameRate() inside setup() [X]
//mouseX, mouseY [X]
//pmouseX, pmouseY vars [x]
//pow() or sqrt() [x]
//dist() or abs() [x]


}