let charImg;
let itemImg;

function preload() {
  charImg = loadImage('Oldman.png');
  itemImg = loadImage('Sword.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20);
  
  textFont('Georgia');
  textSize(20);
  fill(240);
  text('ITS DANGEROUS TO GO ALONE!',45,25);
  text('TAKE THIS.',140,50);
  
  image(charImg, 175,180);
  image(itemImg, mouseX-25, mouseY-25);
}