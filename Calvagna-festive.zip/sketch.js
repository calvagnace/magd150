 var x = []
function setup() {
  createCanvas(600, 400);
  colorMode(RGB,255,255,255,100);
  noStroke();
  for (var i = 0; i < 40; i++) {
      x[i] = random(-200, 4000); 
   }
}

function draw() {
   var mPosX = mouseX
   var mPosY = mouseY
   var a = [mPosX, mPosY, 63, 82, 110, 146, 164, 235, 274, 277]
   print(a.length);
   ellipseMode(RADIUS);
    background(235, 133, 97);
    fill(251, 217, 170);
    ellipse(430,70,40,40);
    
   //stars
    ellipse(a[2],a[3],5,5);
    ellipse(a[4],a[5],5,5);
    ellipse(a[6],a[7],5,5);
    ellipse(a[8],a[9],5,5);
    ellipse(a[3],a[2],5,5);
    ellipse(a[5],a[4],5,5);
    ellipse(a[7],a[6],5,5);
    ellipse(a[9],a[8],5,5);
    ellipse(a[4],a[9],5,5);
    ellipse(a[6],a[3],5,5);
    ellipse(a[8],a[7],5,5);
    ellipse(a[5],a[8],5,5);
    ellipse(a[4]+50,a[9]-70,5,5);
    ellipse(a[6]+50,a[3]-60,5,5);
    ellipse(a[8]+50,a[7]-60,5,5);
    ellipse(a[5]+50,a[8]-60,5,5);
    ellipse(a[6]+250,a[7],5,5);
    ellipse(a[8]+250,a[9],5,5);
    ellipse(a[3]+250,a[2],5,5);
    ellipse(a[5]+250,a[4],5,5);
    ellipse(a[3]-90,a[2],5,5);
    ellipse(a[5]-50,a[4]+100,5,5);
    ellipse(a[7]-100,a[6]+100,5,5);
    ellipse(a[9]-100,a[8],5,5);

    fill(235, 133, 97);
    ellipse(460,60,40,40);

fill(20,20,20);
ellipse(mPosX,mPosY+3,8,8);
ellipse(mPosX,mPosY+20,12,16);
triangle(mPosX-8,mPosY+1,mPosX-5,mPosY-10,mPosX-1,mPosY-2);
triangle(mPosX+8,mPosY+1,mPosX+5,mPosY-10,mPosX+1,mPosY-2);
quad(mPosX-70,mPosY,mPosX-30,mPosY,mPosX,mPosY+10,mPosX,mPosY+50);
quad(mPosX,mPosY+10,mPosX,mPosY+50,mPosX+70,mPosY,mPosX+30,mPosY);

scale(.3);
   for (var i = 0; i < x.length; i++) {
      x[i] +=5;
      var y = i * 16;
fill(20,20,20);
    //x=300
    //y=200  } my notes for variable replacement
ellipse(x[i],y+3,8,8);
ellipse(x[i],y+20,12,16);
triangle(x[i]-8,y+1,x[i]-5,y-10,x[i]-1,y-2);
triangle(x[i]+8,y+1,x[i]+5,y-10,x[i]+1,y-2);
quad(x[i]-70,y,x[i]-30,y,x[i],y+10,x[i],y+50);
quad(x[i],y+10,x[i],y+50,x[i]+70,y,x[i]+30,y);
   }

//original bat shape for referecnce
//ellipse(300,203,8,8);
//ellipse(300,220,12,16);
//triangle(292,201,295,190,299,198,8);
//triangle(308,201,305,190,301,198,8);
//quad(230,200,270,200,300,210,300,250);
//quad(300,210,300,250,370,200,330,200);
scale(3.3333);

fill(20,20,20);
rect(0,350,600,50);
ellipse(147,330,40,40);
quad(135,250,160,250,180,320,115,320);
ellipse(147,250,25,25);
triangle(140,210,140,275,110,260);
triangle(155,210,155,275,185,260);



}

//code requirements:

//THEME: 
  //Halloween, Retro game, or Nature [x]

//CODING ELEMENTS:
  //400x400+ canvas [x]
  //Create and assign values to an array [x]
  //Use print() to determine the length of the numbered array [x]
  //Create an array and assign values to the array using a for() loop [x]
  //Set a value in the array to the current mouse position value [x]
  //No errors / check in p5js [x]
         